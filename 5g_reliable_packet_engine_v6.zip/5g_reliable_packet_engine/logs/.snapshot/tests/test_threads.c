/* test_threads.c - pure C11/pthread concurrency test for Helgrind / TSan.
 * No GoogleTest needed (gtest's own internals can trigger Helgrind noise).
 * The engine keeps no global state, so independent simulations running in
 * parallel threads, each with its OWN config/stats/tree, must be race-free. */
/* _POSIX_C_SOURCE is supplied by the Makefile (CSTD). */
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include "bst.h"
#include "logger.h"
#include "sliding_window.h"

#define THREADS 4U

typedef struct {
    uint32_t     index;
    status_t     rc;
    sw_stats_t   stats;
    uint32_t     tree_count;
    char         stamp[LOGGER_TS_LEN];
    status_t     ts_rc;
} job_t;

static void *worker(void *arg)
{
    job_t *job = (job_t *)arg;
    sw_config_t cfg;
    bst_t tree;
    station_id_t id;

    (void)memset(&job->stats, 0, sizeof(job->stats));
    sw_config_default(&cfg);
    cfg.packet_count = 60U;
    cfg.data_loss_percent = 10U;
    cfg.seed = 100U + job->index;
    job->rc = sw_simulate(&cfg, 1U, 2U, NULL, &job->stats);

    bst_init(&tree);
    for (id = 1U; id <= 200U; id++) {
        station_t s;
        if (station_init(&s, id, "Node", id, 100U, 1U, "Relay") == STATUS_OK) {
            (void)bst_insert(&tree, &s);
        }
    }
    job->tree_count = tree.count;
    bst_destroy(&tree);

    job->ts_rc = logger_timestamp(job->stamp, sizeof(job->stamp));   /* IST, thread-safe */
    return NULL;
}

int main(void)
{
    pthread_t th[THREADS];
    job_t jobs[THREADS];
    uint32_t i;
    int failed = 0;

    (void)memset(jobs, 0, sizeof(jobs));
    for (i = 0U; i < THREADS; i++) {
        jobs[i].index = i;
        if (pthread_create(&th[i], NULL, worker, &jobs[i]) != 0) {
            (void)fprintf(stderr, "pthread_create failed\n");
            return 1;
        }
    }
    for (i = 0U; i < THREADS; i++) {
        (void)pthread_join(th[i], NULL);
    }
    for (i = 0U; i < THREADS; i++) {
        if ((jobs[i].rc != STATUS_OK) || (jobs[i].stats.delivered != 60U) ||
            (jobs[i].tree_count != 200U) || (jobs[i].ts_rc != STATUS_OK)) {
            (void)printf("FAIL thread %u\n", (unsigned)i);
            failed = 1;
        }
    }
    (void)printf("%s: %u threads\n", failed ? "FAILED" : "PASSED", THREADS);
    return failed;
}
