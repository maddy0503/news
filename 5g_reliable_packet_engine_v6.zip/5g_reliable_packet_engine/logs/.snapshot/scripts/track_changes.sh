#!/bin/sh
# track_changes.sh - records every change to the project's source files.
#
# Called automatically by `make` (all, test, valgrind, cppcheck, ...) and by
# `make track`. It compares the tracked files with the copy saved the last time
# it ran (logs/.snapshot/) and, if anything changed, APPENDS one entry to
# logs/change_log.txt containing:
#   - entry number, date/time in IST (UTC+05:30), user, host
#   - an optional reason:   make track NOTE="why I changed this"
#   - per file: ADDED / MODIFIED / DELETED, lines added/removed, SHA-256,
#     and the full unified diff of what changed (capped at MAX_DIFF lines).
# If nothing changed, nothing is written.
set -u

LOG="logs/change_log.txt"
SNAP="logs/.snapshot"
MAX_DIFF=400
TRACKED_DIRS="src include tests scripts config"
TRACKED_FILES="Makefile README.md"

mkdir -p logs "$SNAP"

# IST = UTC+05:30 (fixed offset, independent of the machine's TZ setting).
ist_now() {
    date -u -d '+5 hours 30 minutes' '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -u '+%Y-%m-%d %H:%M:%S'
}

hash_of() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" | cut -d' ' -f1
    else
        cksum "$1" | cut -d' ' -f1
    fi
}

list_current() {
    for f in $TRACKED_FILES; do [ -f "$f" ] && echo "$f"; done
    for d in $TRACKED_DIRS; do
        [ -d "$d" ] && find "$d" -type f ! -name '*.o' ! -name '*.gc*' | sort
    done
}

list_snapshot() {
    (cd "$SNAP" 2>/dev/null && find . -type f | sed 's|^\./||' | sort)
}

TMP=$(mktemp 2>/dev/null || echo "/tmp/track_changes.$$")
: > "$TMP"
changed=0
added_n=0; mod_n=0; del_n=0

# ---- added / modified ---------------------------------------------------------
for f in $(list_current); do
    if [ ! -f "$SNAP/$f" ]; then
        lines=$(wc -l < "$f" | tr -d ' ')
        {
            echo "  [ADDED]    $f  ($lines lines, sha256 $(hash_of "$f"))"
        } >> "$TMP"
        changed=1; added_n=$((added_n + 1))
    elif ! cmp -s "$f" "$SNAP/$f"; then
        d=$(diff -u "$SNAP/$f" "$f")
        plus=$(printf '%s\n' "$d" | grep -c '^+[^+]')
        minus=$(printf '%s\n' "$d" | grep -c '^-[^-]')
        {
            echo "  [MODIFIED] $f  (+$plus / -$minus lines, sha256 $(hash_of "$f"))"
            printf '%s\n' "$d" | head -n "$MAX_DIFF" | sed 's/^/      | /'
            total=$(printf '%s\n' "$d" | wc -l | tr -d ' ')
            [ "$total" -gt "$MAX_DIFF" ] && echo "      | ... diff truncated ($total lines total)"
        } >> "$TMP"
        changed=1; mod_n=$((mod_n + 1))
    fi
done

# ---- deleted ------------------------------------------------------------------
for f in $(list_snapshot); do
    if [ ! -f "$f" ]; then
        echo "  [DELETED]  $f" >> "$TMP"
        changed=1; del_n=$((del_n + 1))
    fi
done

if [ "$changed" -eq 0 ]; then
    rm -f "$TMP"
    echo "change log: no source changes since last run."
    exit 0
fi

# ---- write the entry ----------------------------------------------------------
if [ ! -f "$LOG" ]; then
    {
        echo "5G Reliable Packet Engine - CHANGE LOG"
        echo "All times are Indian Standard Time (IST, UTC+05:30)."
        echo "Entries are appended automatically by scripts/track_changes.sh"
        echo "(run by make). Add a reason with:  make track NOTE=\"what and why\""
        echo
    } > "$LOG"
fi
n=$(grep -c '^=== CHANGE #' "$LOG")
n=$((n + 1))
{
    echo "=== CHANGE #$n | $(ist_now) IST | user: $(id -un 2>/dev/null || echo unknown) | host: $(hostname 2>/dev/null || echo unknown)"
    [ -n "${NOTE:-}" ] && echo "  reason: $NOTE"
    echo "  summary: $added_n added, $mod_n modified, $del_n deleted"
    cat "$TMP"
    echo
} >> "$LOG"
rm -f "$TMP"

# ---- refresh the snapshot -----------------------------------------------------
rm -rf "$SNAP"; mkdir -p "$SNAP"
for f in $(list_current); do
    mkdir -p "$SNAP/$(dirname "$f")"
    cp "$f" "$SNAP/$f"
done
echo "change log: entry #$n written to $LOG ($added_n added, $mod_n modified, $del_n deleted)."
exit 0
