/* common.h - shared status codes and basic types (C11). */
#ifndef COMMON_H
#define COMMON_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* One status type is used by every module so callers can check results uniformly. */
typedef enum {
    STATUS_OK = 0,
    STATUS_ERR_NULL,          /* NULL pointer argument            */
    STATUS_ERR_RANGE,         /* value outside the permitted range */
    STATUS_ERR_FORMAT,        /* malformed text / file content    */
    STATUS_ERR_DUPLICATE,     /* key already exists               */
    STATUS_ERR_NOT_FOUND,     /* key does not exist               */
    STATUS_ERR_EMPTY,         /* container is empty               */
    STATUS_ERR_FULL,          /* container / window is full       */
    STATUS_ERR_NOMEM,         /* malloc failed                    */
    STATUS_ERR_IO,            /* file or stream error / EOF       */
    STATUS_ERR_STATE,         /* internal state inconsistent      */
    STATUS_ERR_SAME_ENDPOINT, /* source == destination            */
    STATUS_ERR_MAX_RETRIES    /* retransmission limit exceeded    */
} status_t;

/* Returns a constant, human-readable description (never NULL). */
const char *status_to_string(status_t status);

#endif /* COMMON_H */
