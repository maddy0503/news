#!/bin/sh
# Prints line, branch and function coverage per source file from gcov output.
# usage: coverage_summary.sh "src/a.c src/b.c"
tl=0; tc=0; tb=0; tbt=0; tf=0; tfc=0
printf "%-24s %8s %9s %10s\n" "File" "Lines%" "Branch%" "Func%"
for f in $1; do
  out=$(gcov -b -f -n -o build/cov "$f" 2>/dev/null)
  lines=$(printf '%s\n' "$out" | awk -v f="$f" '$0 ~ "^File .*"f"" {g=1;next} g && /^Lines executed/ {print;exit}')
  br=$(printf '%s\n' "$out" | awk -v f="$f" '$0 ~ "^File .*"f"" {g=1;next} g && /^Taken at least once/ {print;exit}')
  lp=$(echo "$lines" | sed 's/.*:\([0-9.]*\)%.*/\1/'); ln=$(echo "$lines" | sed 's/.* of //')
  bp=$(echo "$br" | sed 's/.*:\([0-9.]*\)%.*/\1/'); bn=$(echo "$br" | sed 's/.* of //')
  nf=$(printf '%s\n' "$out" | grep -c "^Function '")
  nc=$(printf '%s\n' "$out" | awk '/^Function /{fn=1;next} fn && /^Lines executed/ {split($0,a,":");split(a[2],b,"%"); if (b[1]+0>0) c++; fn=0} END{print c+0}')
  fp=$(awk -v c="$nc" -v n="$nf" 'BEGIN{ if(n>0) printf "%.1f", 100*c/n; else print "n/a"}')
  printf "%-24s %8s %9s %10s  (%s/%s functions)\n" "$f" "$lp" "$bp" "$fp" "$nc" "$nf"
  tl=$((tl+ln)); tc=$(awk -v a="$tc" -v p="$lp" -v n="$ln" 'BEGIN{printf "%.4f", a+p*n/100}')
  tb=$((tb+bn)); tbt=$(awk -v a="$tbt" -v p="$bp" -v n="$bn" 'BEGIN{printf "%.4f", a+p*n/100}')
  tf=$((tf+nf)); tfc=$((tfc+nc))
done
awk -v l="$tl" -v c="$tc" -v b="$tb" -v bt="$tbt" -v f="$tf" -v fc="$tfc" 'BEGIN{
  printf "%-24s %7.1f%% %8.1f%% %9.1f%%\n", "TOTAL", 100*c/l, 100*bt/b, 100*fc/f}'
