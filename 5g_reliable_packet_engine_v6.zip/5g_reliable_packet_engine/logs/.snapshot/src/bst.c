/* bst.c - iterative Binary Search Tree keyed by Station ID. */
#include <stdlib.h>
#include "bst.h"

void bst_init(bst_t *tree)
{
    if (tree != NULL) {
        tree->root = NULL;
        tree->count = 0U;
    }
}

/* Returns the link (pointer to a child/root pointer) that holds the node with
 * this ID, or the NULL link where such a node would have to be inserted. */
static bst_node_t **find_link(bst_t *tree, station_id_t id)
{
    bst_node_t **link = &tree->root;

    while ((*link != NULL) && ((*link)->data.id != id)) {
        link = (id < (*link)->data.id) ? &(*link)->left : &(*link)->right;
    }
    return link;
}

status_t bst_insert(bst_t *tree, const station_t *station)
{
    status_t rc;

    if ((tree == NULL) || (station == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        rc = station_validate(station);
        if ((rc == STATUS_OK) && (tree->count >= BST_MAX_STATIONS)) {
            rc = STATUS_ERR_FULL;
        }
        if (rc == STATUS_OK) {
            /* "link" points at the pointer that must receive the new node. */
            bst_node_t **link = find_link(tree, station->id);

            if (*link != NULL) {
                rc = STATUS_ERR_DUPLICATE;
            } else {
                bst_node_t *node = (bst_node_t *)malloc(sizeof(*node));

                if (node == NULL) {
                    rc = STATUS_ERR_NOMEM;
                } else {
                    node->data = *station;
                    node->left = NULL;
                    node->right = NULL;
                    *link = node;
                    tree->count++;
                }
            }
        }
    }
    return rc;
}

const station_t *bst_search(const bst_t *tree, station_id_t id)
{
    const station_t *found = NULL;

    if (tree != NULL) {
        const bst_node_t *cur = tree->root;

        while ((cur != NULL) && (found == NULL)) {
            if (id == cur->data.id) {
                found = &cur->data;
            } else {
                cur = (id < cur->data.id) ? cur->left : cur->right;
            }
        }
    }
    return found;
}

status_t bst_update(bst_t *tree, station_id_t id, const char *name,
                    uint32_t distance_km, uint32_t fare, uint32_t platform,
                    const char *type)
{
    status_t rc;

    if (tree == NULL) {
        rc = STATUS_ERR_NULL;
    } else {
        station_t updated;

        /* Validate the new values BEFORE touching the stored record. */
        rc = station_init(&updated, id, name, distance_km, fare, platform, type);
        if (rc == STATUS_OK) {
            bst_node_t **link = find_link(tree, id);

            if (*link == NULL) {
                rc = STATUS_ERR_NOT_FOUND;
            } else {
                (*link)->data = updated;   /* key unchanged -> BST order intact */
            }
        }
    }
    return rc;
}

status_t bst_delete(bst_t *tree, station_id_t id)
{
    status_t rc;

    if (tree == NULL) {
        rc = STATUS_ERR_NULL;
    } else {
        bst_node_t **link = find_link(tree, id);

        if (*link == NULL) {
            rc = STATUS_ERR_NOT_FOUND;
        } else {
            bst_node_t *victim = *link;

            if (victim->left == NULL) {             /* leaf or only right child */
                *link = victim->right;
            } else if (victim->right == NULL) {     /* only left child */
                *link = victim->left;
            } else {                                /* two children */
                bst_node_t **succ_link = &victim->right;
                bst_node_t *succ;

                while ((*succ_link)->left != NULL) {    /* inorder successor */
                    succ_link = &(*succ_link)->left;
                }
                succ = *succ_link;
                *succ_link = succ->right;           /* detach successor */
                succ->left = victim->left;
                succ->right = victim->right;
                *link = succ;                       /* splice into victim's place */
            }
            free(victim);
            tree->count--;
            rc = STATUS_OK;
        }
    }
    return rc;
}

status_t bst_inorder(const bst_t *tree, bst_visit_fn visit, void *context)
{
    status_t rc = STATUS_OK;

    if ((tree == NULL) || (visit == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        const bst_node_t *stack[BST_MAX_STATIONS];
        size_t sp = 0U;
        const bst_node_t *cur = tree->root;

        while (((cur != NULL) || (sp > 0U)) && (rc == STATUS_OK)) {
            while ((cur != NULL) && (rc == STATUS_OK)) {
                if (sp >= BST_MAX_STATIONS) {
                    rc = STATUS_ERR_STATE;
                } else {
                    stack[sp] = cur;
                    sp++;
                    cur = cur->left;
                }
            }
            if (rc == STATUS_OK) {
                sp--;
                cur = stack[sp];
                visit(&cur->data, context);
                cur = cur->right;
            }
        }
    }
    return rc;
}

status_t bst_preorder(const bst_t *tree, bst_visit_fn visit, void *context)
{
    status_t rc = STATUS_OK;

    if ((tree == NULL) || (visit == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        const bst_node_t *stack[BST_MAX_STATIONS];
        size_t sp = 0U;

        if (tree->root != NULL) {
            stack[0] = tree->root;
            sp = 1U;
        }
        while ((sp > 0U) && (rc == STATUS_OK)) {
            const bst_node_t *cur;

            sp--;
            cur = stack[sp];
            visit(&cur->data, context);
            if ((sp + 2U) > BST_MAX_STATIONS) {
                rc = STATUS_ERR_STATE;
            } else {
                if (cur->right != NULL) { stack[sp] = cur->right; sp++; }
                if (cur->left != NULL)  { stack[sp] = cur->left;  sp++; }
            }
        }
    }
    return rc;
}

status_t bst_stats(const bst_t *tree, uint32_t *count, station_id_t *min_id,
                   station_id_t *max_id)
{
    status_t rc = STATUS_OK;

    if ((tree == NULL) || (count == NULL) || (min_id == NULL) || (max_id == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        *count = tree->count;
        if (tree->root == NULL) {
            *min_id = 0U;
            *max_id = 0U;
            rc = STATUS_ERR_EMPTY;
        } else {
            const bst_node_t *cur = tree->root;

            while (cur->left != NULL)  { cur = cur->left; }
            *min_id = cur->data.id;
            cur = tree->root;
            while (cur->right != NULL) { cur = cur->right; }
            *max_id = cur->data.id;
        }
    }
    return rc;
}

void bst_destroy(bst_t *tree)
{
    if (tree != NULL) {
        /* Constant-space teardown: rotate left children up, then free the root. */
        bst_node_t *cur = tree->root;

        while (cur != NULL) {
            if (cur->left != NULL) {
                bst_node_t *l = cur->left;
                cur->left = l->right;
                l->right = cur;
                cur = l;
            } else {
                bst_node_t *next = cur->right;
                free(cur);
                cur = next;
            }
        }
        tree->root = NULL;
        tree->count = 0U;
    }
}
