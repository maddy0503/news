#!/bin/sh
# run_logged.sh <label> <command...>
# Runs one quality step (test, gtest, misra, cppcheck, valgrind, helgrind, ...),
# shows its output as usual and appends a record to logs/test_run_log.txt:
#   IST date/time | make <label> | PASS/FAIL (exit code) | duration | Makefile SHA-256
#   + the key result lines (test counts, "no errors", MISRA findings, ...)
#   + on FAIL: every finding / the last 60 lines of output.
# The exit code of the step is passed through unchanged.
set -u
LABEL=$1; shift
RUNLOG="logs/test_run_log.txt"
mkdir -p logs
TMP=$(mktemp 2>/dev/null || echo "/tmp/run_logged.$$")
RCF="$TMP.rc"

ist_now() { date -u -d '+5 hours 30 minutes' '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date -u '+%Y-%m-%d %H:%M:%S'; }
mk_hash() {
    if command -v sha256sum >/dev/null 2>&1; then sha256sum Makefile | cut -c1-12; else echo n/a; fi
}

start=$(date +%s)
{ "$@"; echo $? > "$RCF"; } 2>&1 | tee "$TMP"
rc=$(cat "$RCF" 2>/dev/null || echo 1)
end=$(date +%s)

[ -f "$RUNLOG" ] || {
    echo "5G Reliable Packet Engine - TEST / ANALYSIS RUN LOG"
    echo "One record per 'make <target>' run (test, gtest, coverage, cppcheck, misra,"
    echo "valgrind, helgrind, tsan, sanitize, functional). Times are IST (UTC+05:30)."
    echo "'makefile' = first 12 hex digits of the Makefile SHA-256 used for that run;"
    echo "Makefile edits themselves are recorded in logs/change_log.txt."
    echo
} > "$RUNLOG"

if [ "$rc" -eq 0 ]; then status=PASS; else status=FAIL; fi
{
    echo "$(ist_now) IST | make $LABEL | $status (exit $rc) | $((end - start))s | makefile $(mk_hash) | user $(id -un 2>/dev/null || echo unknown)"
    grep -E 'test cases|ALL TEST SUITES|PASSED|SANITIZERS|VALGRIND:|HELGRIND:|MISRA findings|ERROR SUMMARY|TOTAL|OK \(|\[  PASSED  \]|\[  FAILED  \]|ERROR:|NOTE:|FAILED' "$TMP" | head -n 20 | sed 's/^/    > /'
    if [ "$status" = FAIL ]; then
        echo "    --- findings / failure detail ---"
        if grep -qE ': (style|warning|error|performance|portability):' "$TMP"; then
            grep -E ': (style|warning|error|performance|portability):' "$TMP" | sed 's/^/    ! /'
        else
            tail -n 60 "$TMP" | sed 's/^/    ! /'
        fi
    fi
    echo
} >> "$RUNLOG"
rm -f "$TMP" "$RCF"
echo "run log: 'make $LABEL' = $status recorded in $RUNLOG"
exit "$rc"
