/* logger.h - timestamped logging for every process of the engine.
 *
 * Every line is prefixed with a wall-clock timestamp in Indian Standard Time (IST, UTC+05:30),
 * millisecond resolution:
 *     2026-10-28 14:03:21.457 | INFO  | main   | START add_station
 * The logger holds NO global state: each logger_t is an independent object, so
 * the library stays thread-safe (see tests/gtest/test_threads_gtest.cpp).
 * The clock is injectable so that tests can produce reproducible timestamps.
 */
#ifndef LOGGER_H
#define LOGGER_H

#include <stdio.h>
#include "common.h"

#define LOGGER_TS_LEN       32U    /* "YYYY-MM-DD HH:MM:SS.mmm" + NUL = 24 */
#define LOGGER_MODULE_MAX   16U
#define LOGGER_MESSAGE_MAX  256U

typedef enum {
    LOG_DEBUG = 0,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR
} log_level_t;

/* Returns milliseconds since the Unix epoch (UTC). */
typedef uint64_t (*logger_clock_fn)(void);

typedef struct {
    FILE           *file;        /* log file (may be NULL)                   */
    FILE           *console;     /* echo stream, e.g. stderr (may be NULL)   */
    log_level_t     min_level;   /* lines below this level are dropped       */
    logger_clock_fn clock;       /* never NULL after logger_init()           */
    bool            use_utc;     /* true: UTC, false: IST (UTC+05:30, default)*/
    bool            owns_file;   /* true: logger_close() fcloses the file    */
    uint32_t        lines;       /* number of lines written so far           */
} logger_t;

/* Wall clock in ms since the Unix epoch; 0 if the clock is unavailable. */
uint64_t logger_now_ms(void);

/* use_utc=false formats in IST (UTC+05:30); true in UTC.
 * Formats epoch_ms as "YYYY-MM-DD HH:MM:SS.mmm" into buffer.
 * STATUS_ERR_NULL (buffer NULL), STATUS_ERR_RANGE (capacity < LOGGER_TS_LEN
 * or time not representable). */
status_t logger_format_time(uint64_t epoch_ms, bool use_utc, char *buffer,
                            size_t capacity);

/* Convenience: formats the current time in IST. */
status_t logger_timestamp(char *buffer, size_t capacity);

const char *logger_level_name(log_level_t level);

/* Initialises a logger that writes to already-open streams (either may be NULL). */
status_t logger_init(logger_t *logger, FILE *file, FILE *console,
                     log_level_t min_level);

/* Opens (appends to) a log file and initialises the logger. */
status_t logger_open(logger_t *logger, const char *path, FILE *console,
                     log_level_t min_level);

void     logger_set_clock(logger_t *logger, logger_clock_fn clock_fn);
void     logger_set_utc(logger_t *logger, bool use_utc);

/* printf-style, timestamped, single-line log record. Embedded CR/LF in the
 * message are replaced by spaces (prevents log-forging). Messages longer than
 * LOGGER_MESSAGE_MAX-1 characters are truncated. */
status_t logger_log(logger_t *logger, log_level_t level, const char *module,
                    const char *fmt, ...);

void     logger_close(logger_t *logger);

#endif /* LOGGER_H */
