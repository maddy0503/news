/* sliding_window.c - Go-Back-N ARQ over a deterministic tick-based channel.
 *
 * Simulation model (one iteration of the main loop == one tick):
 *   1. receiver processes data packets whose delivery tick has arrived
 *   2. sender processes ACKs whose delivery tick has arrived
 *   3. sender checks its (single, oldest-packet) retransmission timer
 *   4. sender transmits new packets while the window has room
 * One-way delay is SW_PROP_DELAY ticks, so the round-trip time is 2 ticks.
 *
 * Complexity: ring-buffer / queue operations O(1); one simulation tick
 * costs O(window); total time O(ticks * window), space O(1) (fixed arrays).
 */
#include <stdarg.h>
#include <string.h>
#include "sliding_window.h"

/* ------------------------------------------------------------------ config */

status_t sw_config_default(sw_config_t *config)
{
    status_t rc = STATUS_OK;

    if (config == NULL) {
        rc = STATUS_ERR_NULL;
    } else {
        (void)memset(config, 0, sizeof(*config));
        config->window_size = 4U;
        config->packet_count = 12U;
        config->timeout_ticks = 5U;
        config->max_retries = 6U;
        config->data_loss_every = 5U;     /* deterministic pattern */
        config->ack_loss_every = 7U;
        config->data_loss_percent = 0U;
        config->ack_loss_percent = 0U;
        config->seed = 12345U;
    }
    return rc;
}

status_t sw_config_validate(const sw_config_t *config)
{
    status_t rc = STATUS_OK;

    if (config == NULL) {
        rc = STATUS_ERR_NULL;
    } else if ((config->window_size < 1U) || (config->window_size > SW_WINDOW_MAX) ||
               (config->packet_count < 1U) || (config->packet_count > SW_MAX_PACKETS) ||
               (config->timeout_ticks < 1U) || (config->timeout_ticks > 100U) ||
               (config->max_retries < 1U) || (config->max_retries > 20U) ||
               (config->data_loss_every > 1000U) || (config->ack_loss_every > 1000U) ||
               (config->data_loss_percent > 100U) || (config->ack_loss_percent > 100U)) {
        rc = STATUS_ERR_RANGE;
    } else {
        /* configuration valid */
    }
    return rc;
}

/* ------------------------------------------------------------------ sender */

status_t sw_sender_init(sw_sender_t *sender, uint8_t window, uint32_t total,
                        station_id_t src, station_id_t dst)
{
    status_t rc = STATUS_OK;

    if (sender == NULL) {
        rc = STATUS_ERR_NULL;
    } else if ((window < 1U) || (window > SW_WINDOW_MAX) || (total < 1U) ||
               (total > SW_MAX_PACKETS)) {
        rc = STATUS_ERR_RANGE;
    } else if ((station_validate_id(src) != STATUS_OK) ||
               (station_validate_id(dst) != STATUS_OK)) {
        rc = STATUS_ERR_RANGE;
    } else {
        (void)memset(sender, 0, sizeof(*sender));
        sender->window = window;
        sender->total = total;
        sender->src = src;
        sender->dst = dst;
    }
    return rc;
}

uint32_t sw_sender_outstanding(const sw_sender_t *sender)
{
    return (sender == NULL) ? 0U : (sender->next_abs - sender->base_abs);
}

/* Flow control: never more than "window" unacknowledged packets. */
bool sw_sender_can_send(const sw_sender_t *sender)
{
    return (sender != NULL) && (sw_sender_outstanding(sender) < sender->window) &&
           (sender->next_abs < sender->total);
}

status_t sw_sender_next_packet(sw_sender_t *sender, const uint8_t *payload,
                               size_t length, uint32_t now, packet_t **out)
{
    status_t rc;

    if ((sender == NULL) || (out == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if (sw_sender_outstanding(sender) >= sender->window) {
        rc = STATUS_ERR_FULL;              /* window closed */
    } else if (sender->next_abs >= sender->total) {
        rc = STATUS_ERR_EMPTY;             /* nothing left to send */
    } else {
        bool was_empty = (sw_sender_outstanding(sender) == 0U);
        uint8_t seq = (uint8_t)(sender->next_abs % SEQ_MODULUS);
        packet_t *slot = &sender->slots[seq];   /* ring buffer indexed by seq */

        rc = packet_init(slot, seq, sender->src, sender->dst, payload, length);
        if (rc == STATUS_OK) {
            slot->status = PKT_STATUS_SENT;
            slot->sent_tick = now;
            if (was_empty) {
                sender->timer_start = now;     /* timer guards the oldest packet */
            }
            sender->next_abs++;
            *out = slot;
        }
    }
    return rc;
}

/* Cumulative ACK: ack_seq names the NEXT sequence the receiver expects, so
 * everything before it is acknowledged. Duplicate / stale ACKs are ignored. */
status_t sw_sender_process_ack(sw_sender_t *sender, uint8_t ack_seq,
                               uint32_t now, uint32_t *advanced)
{
    status_t rc = STATUS_OK;

    if ((sender == NULL) || (advanced == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        *advanced = 0U;
        if (ack_seq >= SEQ_MODULUS) {
            rc = STATUS_ERR_RANGE;
        } else {
            uint32_t outstanding = sw_sender_outstanding(sender);
            uint8_t dist = seq_distance((uint8_t)(sender->base_abs % SEQ_MODULUS), ack_seq);

            /* dist == 0 or beyond the window: duplicate or stale ACK, ignored. */
            if ((dist != 0U) && ((uint32_t)dist <= outstanding)) {
                uint8_t i;

                for (i = 0U; i < dist; i++) {
                    sender->slots[(sender->base_abs + i) % SEQ_MODULUS].status = PKT_STATUS_ACKED;
                }
                sender->base_abs += dist;      /* slide the window */
                *advanced = dist;
                if (sw_sender_outstanding(sender) > 0U) {
                    sender->timer_start = now; /* restart timer for new oldest */
                }
            }
        }
    }
    return rc;
}

bool sw_sender_timed_out(const sw_sender_t *sender, uint32_t now,
                         uint32_t timeout_ticks)
{
    return (sender != NULL) && (sw_sender_outstanding(sender) != 0U) &&
           (now >= sender->timer_start) &&
           ((now - sender->timer_start) >= timeout_ticks);
}

status_t sw_sender_mark_retransmit(sw_sender_t *sender, uint32_t k,
                                   uint8_t max_retries, uint32_t now,
                                   packet_t **out)
{
    status_t rc = STATUS_OK;

    if ((sender == NULL) || (out == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if (k >= sw_sender_outstanding(sender)) {
        rc = STATUS_ERR_RANGE;
    } else {
        packet_t *slot = &sender->slots[(sender->base_abs + k) % SEQ_MODULUS];

        if (slot->retry_count >= max_retries) {
            rc = STATUS_ERR_MAX_RETRIES;   /* prevents endless retransmission */
        } else {
            slot->retry_count++;
            slot->status = PKT_STATUS_RETRANSMITTED;
            slot->sent_tick = now;
            *out = slot;
        }
    }
    return rc;
}

/* ---------------------------------------------------------------- receiver */

status_t sw_receiver_init(sw_receiver_t *receiver, uint8_t sender_window)
{
    status_t rc = STATUS_OK;

    if (receiver == NULL) {
        rc = STATUS_ERR_NULL;
    } else if ((sender_window < 1U) || (sender_window > SW_WINDOW_MAX)) {
        rc = STATUS_ERR_RANGE;
    } else {
        receiver->expected_seq = 0U;
        receiver->delivered = 0U;
        receiver->sender_window = sender_window;
    }
    return rc;
}

/* Go-Back-N receiver (window = 1): only seq == expected is accepted.
 * Anything else is discarded and answered with the SAME cumulative ACK.
 * Duplicate vs out-of-order is classified for statistics only. */
status_t sw_receiver_on_packet(sw_receiver_t *receiver, const packet_t *packet,
                               ack_t *ack, rx_result_t *result)
{
    status_t rc = STATUS_OK;

    if ((receiver == NULL) || (packet == NULL) || (ack == NULL) || (result == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if (packet->seq >= SEQ_MODULUS) {
        rc = STATUS_ERR_RANGE;
    } else if (!packet_verify(packet)) {
        rc = STATUS_ERR_FORMAT; /* reject corrupted packets before delivery */
    } else {
        uint8_t ahead = seq_distance(receiver->expected_seq, packet->seq);

        if (ahead == 0U) {
            *result = RX_ACCEPTED;
            receiver->expected_seq = seq_next(receiver->expected_seq);
            receiver->delivered++;
        } else {
            uint8_t behind = seq_distance(packet->seq, receiver->expected_seq);

            *result = ((behind <= receiver->sender_window) && (behind <= ahead))
                          ? RX_DUPLICATE
                          : RX_OUT_OF_ORDER;
        }
        ack->ack_seq = receiver->expected_seq;
        ack->src = packet->dst;
        ack->dst = packet->src;
    }
    return rc;
}

/* -------------------------------------------------------------- simulation */

typedef struct {
    const sw_config_t *cfg;
    FILE              *log;
    sw_stats_t        *st;
    pkt_queue_t        data_q;       /* sender -> receiver */
    ack_queue_t        ack_q;        /* receiver -> sender */
    uint32_t           data_counter; /* data transmissions so far */
    uint32_t           ack_counter;
    uint32_t           rng;
    uint32_t           tick;
} sim_ctx_t;

static void sim_log(const sim_ctx_t *c, const char *fmt, ...)
{
    if (c->log != NULL) {
        va_list ap;
        char stamp[LOGGER_TS_LEN];

        if (logger_timestamp(stamp, sizeof(stamp)) != STATUS_OK) {
            (void)snprintf(stamp, sizeof(stamp), "%s", "0000-00-00 00:00:00.000");
        }
        (void)fprintf(c->log, "[%s] [t=%03u] ", stamp, (unsigned)c->tick);
        va_start(ap, fmt);
        (void)vfprintf(c->log, fmt, ap);
        va_end(ap);
        (void)fputc('\n', c->log);
    }
}

/* Deterministic loss: "every Nth" pattern and/or seeded LCG percentage. */
static bool decide_loss(uint32_t counter, uint32_t every, uint8_t percent,
                        uint32_t *rng)
{
    bool lost = false;

    if ((every > 0U) && ((counter % every) == 0U)) {
        lost = true;
    }
    if (percent > 0U) {
        *rng = (*rng * 1664525U) + 1013904223U;   /* LCG, wraps by design */
        if (((*rng >> 16) % 100U) < (uint32_t)percent) {
            lost = true;
        }
    }
    return lost;
}

/* Payload for absolute packet index n; the receiver re-derives it to verify
 * ordered, uncorrupted delivery. */
static size_t make_payload(uint32_t index, uint8_t *buffer, size_t capacity)
{
    size_t len = 0U;
    int n = snprintf((char *)buffer, capacity, "DATA-%05u", (unsigned)index);

    if ((n >= 0) && ((size_t)n < capacity)) {
        len = (size_t)n;
    }
    return len;
}

static void send_data(sim_ctx_t *c, const sw_sender_t *s, const packet_t *p, bool retx)
{
    bool lost;

    c->st->data_tx++;
    if (retx) {
        c->st->retransmissions++;
    }
    c->data_counter++;
    lost = decide_loss(c->data_counter, c->cfg->data_loss_every,
                       c->cfg->data_loss_percent, &c->rng);
    sim_log(c, "SEND  seq=%-2u %s stn %u->%u | sender window [base=%u next=%u]",
            (unsigned)p->seq, retx ? "(retransmit)" : "(new)       ",
            (unsigned)p->src, (unsigned)p->dst,
            (unsigned)(s->base_abs % SEQ_MODULUS),
            (unsigned)(s->next_abs % SEQ_MODULUS));
    if (lost) {
        c->st->data_lost++;
        sim_log(c, "LOSS  data seq=%u lost in channel", (unsigned)p->seq);
    } else if (pktq_push(&c->data_q, p, c->tick + SW_PROP_DELAY) != STATUS_OK) {
        c->st->data_lost++;                /* channel overflow == drop */
        sim_log(c, "LOSS  data seq=%u dropped (channel full)", (unsigned)p->seq);
    } else {
        /* queued for delivery */
    }
}

static status_t step_receiver(sim_ctx_t *c, sw_receiver_t *r)
{
    packet_t p;
    status_t rc = STATUS_OK;

    while ((rc == STATUS_OK) && pktq_pop_due(&c->data_q, c->tick, &p)) {
        ack_t ack;
        rx_result_t res = RX_OUT_OF_ORDER;

        rc = sw_receiver_on_packet(r, &p, &ack, &res);
        if (rc == STATUS_OK) {
            c->st->data_received++;
            if (res == RX_ACCEPTED) {
                uint8_t expect[PAYLOAD_MAX];
                size_t expect_len = make_payload(r->delivered - 1U, expect, sizeof(expect));

                if ((expect_len != p.payload_len) ||
                    (memcmp(expect, p.payload, expect_len) != 0)) {
                    rc = STATUS_ERR_STATE;     /* ordering/integrity violated */
                } else {
                    sim_log(c, "RECV  seq=%-2u accepted, delivered=%u | receiver expects seq=%u",
                            (unsigned)p.seq, (unsigned)r->delivered, (unsigned)r->expected_seq);
                }
            } else if (res == RX_DUPLICATE) {
                c->st->duplicates++;
                sim_log(c, "RECV  seq=%-2u DUPLICATE discarded | receiver expects seq=%u",
                        (unsigned)p.seq, (unsigned)r->expected_seq);
            } else {
                c->st->out_of_order++;
                sim_log(c, "RECV  seq=%-2u OUT-OF-ORDER discarded (Go-Back-N) | receiver expects seq=%u",
                        (unsigned)p.seq, (unsigned)r->expected_seq);
            }
        }
        if (rc == STATUS_OK) {
            bool lost;

            c->st->acks_sent++;
            c->ack_counter++;
            lost = decide_loss(c->ack_counter, c->cfg->ack_loss_every,
                               c->cfg->ack_loss_percent, &c->rng);
            sim_log(c, "ACK   generated ack=%u (next expected)", (unsigned)ack.ack_seq);
            if (lost) {
                c->st->acks_lost++;
                sim_log(c, "LOSS  ACK %u lost in channel", (unsigned)ack.ack_seq);
            } else if (ackq_push(&c->ack_q, &ack, c->tick + SW_PROP_DELAY) != STATUS_OK) {
                c->st->acks_lost++;
            } else {
                /* queued for delivery */
            }
        }
    }
    return rc;
}

static status_t step_acks(sim_ctx_t *c, sw_sender_t *s)
{
    ack_t ack;
    status_t rc = STATUS_OK;

    while ((rc == STATUS_OK) && ackq_pop_due(&c->ack_q, c->tick, &ack)) {
        uint32_t adv = 0U;

        c->st->acks_received++;
        rc = sw_sender_process_ack(s, ack.ack_seq, c->tick, &adv);
        if (rc == STATUS_OK) {
            if (adv > 0U) {
                sim_log(c, "ACK   received ack=%u -> window slides by %u | sender window [base=%u next=%u]",
                        (unsigned)ack.ack_seq, (unsigned)adv,
                        (unsigned)(s->base_abs % SEQ_MODULUS),
                        (unsigned)(s->next_abs % SEQ_MODULUS));
            } else {
                c->st->dup_acks++;
                sim_log(c, "ACK   received ack=%u (duplicate/stale, ignored)",
                        (unsigned)ack.ack_seq);
            }
        }
    }
    return rc;
}

static status_t step_timeout(sim_ctx_t *c, sw_sender_t *s)
{
    status_t rc = STATUS_OK;

    if (sw_sender_timed_out(s, c->tick, c->cfg->timeout_ticks)) {
        uint32_t n = sw_sender_outstanding(s);
        uint32_t k = 0U;
        packet_t *p = NULL;

        c->st->timeouts++;
        sim_log(c, "TIMEOUT oldest unacked seq=%u -> Go-Back-N: resend %u packet(s)",
                (unsigned)(s->base_abs % SEQ_MODULUS), (unsigned)n);
        while ((k < n) && (rc == STATUS_OK)) {
            rc = sw_sender_mark_retransmit(s, k, c->cfg->max_retries, c->tick, &p);
            if (rc != STATUS_OK) {
                sim_log(c, "ABORT retry limit (%u) reached for seq=%u",
                        (unsigned)c->cfg->max_retries,
                        (unsigned)((s->base_abs + k) % SEQ_MODULUS));
            } else {
                send_data(c, s, p, true);
                k++;
            }
        }
        if (rc == STATUS_OK) {
            s->timer_start = c->tick;
        }
    }
    return rc;
}

static status_t step_send_new(sim_ctx_t *c, sw_sender_t *s)
{
    status_t rc = STATUS_OK;

    while ((rc == STATUS_OK) && sw_sender_can_send(s)) {
        uint8_t payload[PAYLOAD_MAX];
        packet_t *p = NULL;
        size_t len = make_payload(s->next_abs, payload, sizeof(payload));

        if (len == 0U) {
            rc = STATUS_ERR_STATE;
        } else {
            rc = sw_sender_next_packet(s, payload, len, c->tick, &p);
            if (rc == STATUS_OK) {
                send_data(c, s, p, false);
            }
        }
    }
    return rc;
}

/* Runs the tick loop; every early-out is expressed through rc. */
static status_t sim_run(const sw_config_t *config, station_id_t src,
                        station_id_t dst, FILE *log, sw_stats_t *stats)
{
    sw_sender_t sender;
    sw_receiver_t receiver;
    status_t rc = sw_sender_init(&sender, config->window_size, config->packet_count, src, dst);

    if (rc == STATUS_OK) {
        rc = sw_receiver_init(&receiver, config->window_size);
    }
    if (rc == STATUS_OK) {
        sim_ctx_t ctx;
        bool finished = false;

        (void)memset(&ctx, 0, sizeof(ctx));
        ctx.cfg = config;
        ctx.log = log;
        ctx.st = stats;
        ctx.rng = (config->seed == 0U) ? 1U : config->seed;
        pktq_init(&ctx.data_q);
        ackq_init(&ctx.ack_q);
        stats->packets_requested = config->packet_count;
        (void)logger_timestamp(stats->started_at, sizeof(stats->started_at));
        sim_log(&ctx, "START simulation: stn %u -> %u, window=%u, packets=%u, timeout=%u",
                (unsigned)src, (unsigned)dst, (unsigned)config->window_size,
                (unsigned)config->packet_count, (unsigned)config->timeout_ticks);

        while ((rc == STATUS_OK) && (!finished) && (ctx.tick < SW_MAX_TICKS)) {
            rc = step_receiver(&ctx, &receiver);
            if (rc == STATUS_OK) {
                rc = step_acks(&ctx, &sender);
            }
            if ((rc == STATUS_OK) && (sender.base_abs >= sender.total)) {
                finished = true;
            }
            if ((rc == STATUS_OK) && (!finished)) {
                rc = step_timeout(&ctx, &sender);
            }
            if ((rc == STATUS_OK) && (!finished)) {
                rc = step_send_new(&ctx, &sender);
            }
            if ((rc == STATUS_OK) && (!finished)) {
                ctx.tick++;
            }
        }
        stats->ticks = ctx.tick;
        stats->delivered = receiver.delivered;
        (void)logger_timestamp(stats->finished_at, sizeof(stats->finished_at));
        if ((rc == STATUS_OK) && (!finished)) {
            rc = STATUS_ERR_STATE;             /* tick budget exhausted */
        }
        if (rc == STATUS_OK) {
            sim_log(&ctx, "DONE  all %u packet(s) delivered in order (stn %u -> %u)",
                    (unsigned)stats->delivered, (unsigned)src, (unsigned)dst);
        }
    }
    return rc;
}

status_t sw_simulate(const sw_config_t *config, station_id_t src,
                     station_id_t dst, FILE *log, sw_stats_t *stats)
{
    status_t rc;

    if ((config == NULL) || (stats == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        (void)memset(stats, 0, sizeof(*stats));
        rc = sw_config_validate(config);
        if (rc == STATUS_OK) {
            rc = sim_run(config, src, dst, log, stats);
        }
    }
    return rc;
}

void sw_print_stats(FILE *out, const sw_stats_t *s)
{
    if ((out != NULL) && (s != NULL)) {
        if (s->started_at[0] != '\0') {
            (void)fprintf(out, "  Started at             : %s\n", s->started_at);
            (void)fprintf(out, "  Finished at            : %s\n", s->finished_at);
        }
        (void)fprintf(out, "  Packets requested      : %u\n", (unsigned)s->packets_requested);
        (void)fprintf(out, "  Packets delivered (ok) : %u\n", (unsigned)s->delivered);
        (void)fprintf(out, "  Data transmissions     : %u (retransmissions: %u)\n",
                      (unsigned)s->data_tx, (unsigned)s->retransmissions);
        (void)fprintf(out, "  Data packets lost      : %u\n", (unsigned)s->data_lost);
        (void)fprintf(out, "  Data packets received  : %u (duplicates: %u, out-of-order: %u)\n",
                      (unsigned)s->data_received, (unsigned)s->duplicates,
                      (unsigned)s->out_of_order);
        (void)fprintf(out, "  ACKs sent / lost / rcvd: %u / %u / %u (duplicate: %u)\n",
                      (unsigned)s->acks_sent, (unsigned)s->acks_lost,
                      (unsigned)s->acks_received, (unsigned)s->dup_acks);
        (void)fprintf(out, "  Timeouts               : %u\n", (unsigned)s->timeouts);
        (void)fprintf(out, "  Simulation ticks       : %u\n", (unsigned)s->ticks);
        if (s->data_tx > 0U) {
            (void)fprintf(out, "  Efficiency (delivered/tx): %u%%\n",
                          (unsigned)((s->delivered * 100U) / s->data_tx));
        }
    }
}
