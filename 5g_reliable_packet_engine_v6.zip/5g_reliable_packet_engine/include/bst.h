/* bst.h - Binary Search Tree of stations, keyed by Station ID.
 *
 * Complexity (n = nodes, h = height; h = log n balanced, n worst case):
 *   insert / search / update / delete : O(h) time, O(1) extra space
 *   inorder / preorder traversal      : O(n) time, O(h) <= O(n) stack
 *   min / max                         : O(h)
 *   destroy                           : O(n) time, O(1) space
 * No recursion is used (MISRA C Rule 17.2). The tree holds at most
 * BST_MAX_STATIONS nodes so every traversal stack is statically bounded.
 */
#ifndef BST_H
#define BST_H

#include "station.h"

#define BST_MAX_STATIONS 1024U

typedef struct bst_node {
    station_t        data;
    struct bst_node *left;
    struct bst_node *right;
} bst_node_t;

typedef struct bst {
    bst_node_t *root;
    uint32_t    count;
} bst_t;

typedef void (*bst_visit_fn)(const station_t *station, void *context);

void     bst_init(bst_t *tree);
status_t bst_insert(bst_t *tree, const station_t *station);
const station_t *bst_search(const bst_t *tree, station_id_t id);
status_t bst_update(bst_t *tree, station_id_t id, const char *name,
                    uint32_t distance_km, uint32_t fare, uint32_t platform,
                    const char *type);
status_t bst_delete(bst_t *tree, station_id_t id);
status_t bst_inorder(const bst_t *tree, bst_visit_fn visit, void *context);
status_t bst_preorder(const bst_t *tree, bst_visit_fn visit, void *context);
status_t bst_stats(const bst_t *tree, uint32_t *count, station_id_t *min_id,
                   station_id_t *max_id);
void     bst_destroy(bst_t *tree);

#endif /* BST_H */
