/* packet.c - packet construction, sequence arithmetic, channel queues. */
#include <string.h>
#include "packet.h"

status_t packet_init(packet_t *packet, uint8_t seq, station_id_t src,
                     station_id_t dst, const uint8_t *payload, size_t length)
{
    status_t rc = STATUS_OK;

    if (packet == NULL) {
        rc = STATUS_ERR_NULL;
    } else if ((length > 0U) && (payload == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if ((seq >= SEQ_MODULUS) || (length > PAYLOAD_MAX)) {
        rc = STATUS_ERR_RANGE;        /* checked BEFORE any copy */
    } else if ((station_validate_id(src) != STATUS_OK) ||
               (station_validate_id(dst) != STATUS_OK)) {
        rc = STATUS_ERR_RANGE;
    } else {
        (void)memset(packet, 0, sizeof(*packet));
        packet->seq = seq;
        packet->src = src;
        packet->dst = dst;
        packet->payload_len = (uint8_t)length;
        if (length > 0U) {
            (void)memcpy(packet->payload, payload, length);
        }
        packet->status = PKT_STATUS_EMPTY;
        packet->checksum = packet_checksum(packet);
    }
    return rc;
}

uint8_t seq_distance(uint8_t from, uint8_t to)
{
    return (uint8_t)(((uint32_t)to + SEQ_MODULUS - (uint32_t)from) % SEQ_MODULUS);
}

uint8_t seq_next(uint8_t seq)
{
    return (uint8_t)(((uint32_t)seq + 1U) % SEQ_MODULUS);
}

/* One Fletcher step: folds a single byte value into the two running sums. */
static void checksum_byte(uint32_t *sum1, uint32_t *sum2, uint32_t value)
{
    *sum1 = (*sum1 + value) % 255U;
    *sum2 = (*sum2 + *sum1) % 255U;
}

/* Folds a 32-bit value, least-significant byte first. */
static void checksum_u32(uint32_t *sum1, uint32_t *sum2, uint32_t value)
{
    uint32_t shift;

    for (shift = 0U; shift < 32U; shift += 8U) {
        checksum_byte(sum1, sum2, (value >> shift) & 0xFFU);
    }
}

/* Fletcher-style lightweight integrity checksum for this simulation. It is
 * intended to detect accidental corruption, not to provide cryptographic
 * authenticity. Header fields and exactly payload_len bytes are included. */
uint16_t packet_checksum(const packet_t *packet)
{
    uint16_t result = 0U;

    if ((packet != NULL) && (packet->payload_len <= PAYLOAD_MAX) &&
        (packet->seq < SEQ_MODULUS)) {
        uint32_t sum1 = 0U;
        uint32_t sum2 = 0U;
        size_t i;

        checksum_byte(&sum1, &sum2, (uint32_t)packet->seq);
        checksum_u32(&sum1, &sum2, (uint32_t)packet->src);
        checksum_u32(&sum1, &sum2, (uint32_t)packet->dst);
        checksum_byte(&sum1, &sum2, (uint32_t)packet->payload_len);
        for (i = 0U; i < packet->payload_len; i++) {
            checksum_byte(&sum1, &sum2, (uint32_t)packet->payload[i]);
        }
        result = (uint16_t)((sum2 << 8U) | sum1);
    }
    return result;
}

bool packet_verify(const packet_t *packet)
{
    return (packet != NULL) && (packet->payload_len <= PAYLOAD_MAX) &&
           (packet->seq < SEQ_MODULUS) && (packet_checksum(packet) == packet->checksum);
}

void pktq_init(pkt_queue_t *queue)
{
    if (queue != NULL) {
        queue->head = 0U;
        queue->count = 0U;
    }
}

status_t pktq_push(pkt_queue_t *queue, const packet_t *packet, uint32_t due_tick)
{
    status_t rc = STATUS_OK;

    if ((queue == NULL) || (packet == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if (queue->count >= CHANNEL_CAP) {
        rc = STATUS_ERR_FULL;
    } else {
        size_t tail = (queue->head + queue->count) % CHANNEL_CAP;

        queue->slots[tail].pkt = *packet;
        queue->slots[tail].due_tick = due_tick;
        queue->count++;
    }
    return rc;
}

bool pktq_pop_due(pkt_queue_t *queue, uint32_t now, packet_t *out)
{
    bool popped = false;

    if ((queue != NULL) && (out != NULL) && (queue->count > 0U) &&
        (queue->slots[queue->head].due_tick <= now)) {
        *out = queue->slots[queue->head].pkt;
        queue->head = (queue->head + 1U) % CHANNEL_CAP;
        queue->count--;
        popped = true;
    }
    return popped;
}

void ackq_init(ack_queue_t *queue)
{
    if (queue != NULL) {
        queue->head = 0U;
        queue->count = 0U;
    }
}

status_t ackq_push(ack_queue_t *queue, const ack_t *ack, uint32_t due_tick)
{
    status_t rc = STATUS_OK;

    if ((queue == NULL) || (ack == NULL)) {
        rc = STATUS_ERR_NULL;
    } else if (queue->count >= CHANNEL_CAP) {
        rc = STATUS_ERR_FULL;
    } else {
        size_t tail = (queue->head + queue->count) % CHANNEL_CAP;

        queue->slots[tail].ack = *ack;
        queue->slots[tail].due_tick = due_tick;
        queue->count++;
    }
    return rc;
}

bool ackq_pop_due(ack_queue_t *queue, uint32_t now, ack_t *out)
{
    bool popped = false;

    if ((queue != NULL) && (out != NULL) && (queue->count > 0U) &&
        (queue->slots[queue->head].due_tick <= now)) {
        *out = queue->slots[queue->head].ack;
        queue->head = (queue->head + 1U) % CHANNEL_CAP;
        queue->count--;
        popped = true;
    }
    return popped;
}
